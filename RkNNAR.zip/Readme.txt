Learning-based Image Interpolation via Robust k-NN Searching for Coherent AR Parameters Estimation

Module Leader: Prof. W.C. Siu, PhD, CEng, FIEE, FHKIE, FIEEE, Chair Professor

Researcher: Dr. Kwok-Wai Hung, PhD (Email: kwokwai.hung(AT)connect.polyu.hk)

Version 1.0
- Initial release.

1). Please cite the following paper when you use the code:
 
  Kwok-Wai Hung, Wan-Chi Siu, Learning-based Image Interpolation via Robust k-NN Searching for Coherent AR Parameters Estimation, Journal of Visual Communication and Image Representation, Vol 31, pp. 305-311, August 2015.
 
2). The current version of the program only support 2x interpolation factor.
 
3). This program support arbitray training data, run 'dictionary_train.m' to build the dictionary for once before running 'Run.m'.    