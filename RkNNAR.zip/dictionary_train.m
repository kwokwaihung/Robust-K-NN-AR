% Learning-based Image Interpolation via Robust k-NN Searching for Coherent AR Parameters Estimation
% 
% Module Leader: Prof. W.C. Siu, PhD, CEng, FIEE, FHKIE, FIEEE, Chair Professor
% 
% PhD Researcher: Dr. K.W. Hung, PhD
% 
% Version 1.0
% - Inital release
% 
% 1). Please cite the following paper when you use the code:
% 
%  Kwok-Wai Hung, Wan-Chi Siu, Learning-based Image Interpolation via Robust k-NN Searching for Coherent AR Parameters Estimation, Journal of Visual Communication and Image Representation, Vol 31, pp. 305-311, August 2015.
% 
% 2). The current version of the program only support 2x interpolation factor.
% 
% 3). This Dictionary training support arbitray training data, run this code to build the dictionary for once before running 'Run.m'.    
% 
% 4). Modify the codes to use different training images.

clear;
noofimage=2;                          % Number of training images
nameIM = cell(noofimage);
nameIM{1}='Input\kodimALL.bmp';       % Default 1st training HR image
nameIM{2}='Input\target.bmp';         % Default 2nd training HR image
% nameIM{3}='Input\****.***';         % Add as needed
nofc=32;                              % Number of clusters

for i=1:noofimage
    
    X=imread([nameIM{i} '']); X=double(X);
    
    % three thresholds
    the=80; the2=20; the3=0.9;
    
    [height,width,~]=size(X);
    
    if rem(height,2)==1
        X=padimage_2D(X,0,1,0,0);
    end
    if rem(width,2)==1
        X=padimage_2D(X,0,0,0,1);
    end
    
    pad=10; X_PAD=padimage_2D(X,pad,pad,pad,pad); [height,width,ch]=size(X_PAD);
    XObserved= double(X_PAD(1:2:height,1:2:width,:)); cluster=1; LRHR=0; dict_training=1; varT=5; % local variance threshold to jump back to bicubic
    
    if ch==3         % color image, run on Y components only; CbCr components are intepolated using bicubic
        X_PAD=rgb2ycbcr(uint8(X_PAD));  X_PAD=double(X_PAD);
        XObserved= double(X_PAD(1:2:height,1:2:width,:));
    end
    
    disp('Initialization....');
    dict_name=['dictionary\all_' int2str(i)];
    refinemap=zeros(height, width);
    [~,~]=RkNNAR(the, the2, the3, LRHR, dict_name, refinemap, varT, dict_training, X_PAD, XObserved);
    
end








% combine dictionaries

for k=1:noofimage
    name=['dictionary\all_' int2str(k)];
    load([name '_yWDict.mat'],'yWDict');  load([name '_yWDict_n.mat'],'yWDict_n');
    load([name '_xWDict_n.mat'],'xWDict_n'); load([name '_xWDict.mat'],'xWDict');
    
    if k==1
        yWDictT=yWDict;
        yWDict_nT=yWDict_n;
        xWDict_nT=xWDict_n;
        xWDictT=xWDict;
    else
        
        yWDict_nT=[yWDict_n yWDict_nT] ;
        xWDict_nT=[xWDict_n xWDict_nT] ;
        yWDictT= cat(3,yWDict, yWDictT);
        xWDictT= cat(3,xWDict, xWDictT);
    end
end

yWDict=yWDictT;
yWDict_n=yWDict_nT;
xWDict_n=xWDict_nT;
xWDict=xWDictT;

name=['dictionary\all'];
save([name '_yWDict.mat'],'yWDict','-v7.3');
save([name '_yWDict_n.mat'],'yWDict_n','-v7.3');
save([name '_xWDict_n.mat'],'xWDict_n','-v7.3');
save([name '_xWDict.mat'],'xWDict','-v7.3');






% k means clustering for k-NN MMSE interpolation

clearvars -except nofc
name='dictionary\all';

disp('Warning!. This step may take several hours to run! Run time depends on your cpu speed, number of clusters, and size of training images.');

load([name '_yWDict_n.mat'],'yWDict_n');

map = kmeans(yWDict_n',nofc,'MaxIter',10000, 'Display','final');

load([name '_xWDict.mat'],'xWDict');
load([name '_yWDict.mat'],'yWDict');

[sy,~]=size(yWDict_n); [syxW,sxxW,~]=size(xWDict); [syyW,sxyW,dictS]=size(yWDict);

% calculate centriods
cen=zeros(sy,nofc);
sumc=zeros(1,nofc);

for i=1:dictS
    %     display(i)
    cen(:,map(i))=cen(:,map(i))+yWDict_n(:,i);
    sumc(:,map(i))=sumc(:,map(i))+1;
end
for i=1:nofc
    cen(:,i)=cen(:,i)/sumc(1,i);
end

% form the sub-dictionary
yWDict_n_k=cell(nofc+1,1);
xWDict_k=cell(nofc,1);
yWDict_k=cell(nofc,1);

% writing the centriods
yWDict_n_k{nofc+1}= cen;

for i=1:nofc
    yWDict_n_k{i}=zeros(sy,sumc(i));
    xWDict_k{i}=zeros(syxW,sxxW,sumc(i));
    yWDict_k{i}=zeros(syyW,sxyW,sumc(i));
end

sumc=zeros(1,nofc);
for i=1:dictS
    %     display(i)
    sumc(:,map(i))=sumc(:,map(i))+1;
    yWDict_n_k{map(i)}(:,sumc(1,map(i)))=yWDict_n(:,i);
    xWDict_k{map(i)}(:,:,sumc(1,map(i)))=xWDict(:,:,i);
    yWDict_k{map(i)}(:,:,sumc(1,map(i)))=yWDict(:,:,i);
end

name='dictionary\';

save([name num2str(nofc) '_all_yWDict_n_k.mat'],'yWDict_n_k','-v7.3');
save([name num2str(nofc) '_all_xWDict_k.mat'],'xWDict_k','-v7.3');
save([name num2str(nofc) '_all_yWDict_k.mat'],'yWDict_k','-v7.3');


clearvars -except nofc




name='dictionary\all';
load([name '_xWDict_n.mat'],'xWDict_n');

map = kmeans(xWDict_n',nofc,'MaxIter',10000, 'Display','final');

load([name '_xWDict.mat'],'xWDict');
load([name '_yWDict.mat'],'yWDict');

[sy,~]=size(xWDict_n); [syxW,sxxW,~]=size(xWDict); [syyW,sxyW,dictS]=size(yWDict);

% calculate centriods
cen=zeros(sy,nofc);
sumc=zeros(1,nofc);

for i=1:dictS
    %     display(i)
    cen(:,map(i))=cen(:,map(i))+xWDict_n(:,i);
    sumc(:,map(i))=sumc(:,map(i))+1;
end
for i=1:nofc
    cen(:,i)=cen(:,i)/sumc(1,i);
end

% form the sub-dictionary
xWDict_n_k=cell(nofc+1,1);
xWDict_k=cell(nofc,1);
yWDict_k=cell(nofc,1);

% writing the centriods
xWDict_n_k{nofc+1}= cen;

for i=1:nofc
    xWDict_n_k{i}=zeros(sy,sumc(i));
    xWDict_k{i}=zeros(syxW,sxxW,sumc(i));
    yWDict_k{i}=zeros(syyW,sxyW,sumc(i));
end

sumc=zeros(1,nofc);
for i=1:dictS
    %     display(i)
    sumc(:,map(i))=sumc(:,map(i))+1;
    xWDict_n_k{map(i)}(:,sumc(1,map(i)))=xWDict_n(:,i);
    xWDict_k{map(i)}(:,:,sumc(1,map(i)))=xWDict(:,:,i);
    yWDict_k{map(i)}(:,:,sumc(1,map(i)))=yWDict(:,:,i);
end

name='dictionary\';

save([name num2str(nofc) '_all_xWDict_n_k.mat'],'xWDict_n_k','-v7.3');
save([name num2str(nofc) '_all_xWDict_k_x.mat'],'xWDict_k','-v7.3');
save([name num2str(nofc) '_all_yWDict_k_x.mat'],'yWDict_k','-v7.3');

clear;

delete(['dictionary\all_*.mat']);
