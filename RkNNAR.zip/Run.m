% Learning-based Image Interpolation via Robust k-NN Searching for Coherent AR Parameters Estimation
% 
% Module Leader: Prof. W.C. Siu, PhD, CEng, FIEE, FHKIE, FIEEE, Chair Professor
% 
% PhD Researcher: Dr. K.W. Hung, PhD
% 
% Version 1.0
% - Inital release
% 
% 1). Please cite the following paper when you use the code:
% 
%  Kwok-Wai Hung, Wan-Chi Siu, Learning-based Image Interpolation via Robust k-NN Searching for Coherent AR Parameters Estimation, Journal of Visual Communication and Image Representation, Vol 31, pp. 305-311, August 2015.
% 
% 2). The current version of the program only support 2x interpolation factor.
% 
% 3). This program support arbitray training data, run 'dictionary_train.m' to build the dictionary for once before running this code.    


clear;
IMAGE= 'foreman';                       % HR image for simulation
Output= ['Output\' IMAGE];
nameIM=['Input\' IMAGE];      
X=imread([nameIM '.tif']); X=double(X);
noofc=32;                               % Number of cluster
dict_name=['dictionary\' int2str(noofc) '_all'];      % Name and location of dictionary

% three thresholds
the=80; the2=20; the3=0.9;

[height,width,ch]=size(X);

if rem(height,2)==1
    X=padimage_2D(X,0,1,0,0);
end
if rem(width,2)==1
    X=padimage_2D(X,0,0,0,1);
end

pad=10; X_PAD=padimage_2D(X,pad,pad,pad,pad); [height,width,ch]=size(X_PAD);
XObserved= double(X_PAD(1:2:height,1:2:width,:)); cluster=1; LRHR=0; dict_training=0; varT=5; % local variance threshold to jump back to bicubic
X_PAD_BIC(:,:,1)=double(bicubic(XObserved(:,:,1),2,2)); 

if ch==3         % color image, run on Y components only; CbCr components are intepolated using bicubic
    X_PAD=rgb2ycbcr(uint8(X_PAD));  X_PAD=double(X_PAD);
    XObserved= double(X_PAD(1:2:height,1:2:width,:));
    for i=1:3 
        X_PAD_BIC(:,:,i)=double(bicubic(XObserved(:,:,i),2,2)); 
    end
end

if ch==1 imwrite(uint8(XObserved), [Output '_DS.bmp']);  % save down-sampled images
else imwrite(ycbcr2rgb(uint8(XObserved)), [Output '_DS.bmp']);  % save down-sampled images
end
BicubicPSNR = csnr(X_PAD_BIC(:,:,1), X_PAD(:,:,1), pad+5, pad+5)
X_PAD_TEMP=X_PAD_BIC(:,:,1);  % Bicubic as initial HR image

    disp('Initialization....');
    disp('Warning!. This step may take several minutes to run! Run time depends on your cpu speed, number of clusters, and size of dictionary and images.');
    refinemap=zeros(height, width);
    [X_PAD_TEMP,~]=RkNNAR(the, the2, the3, LRHR, dict_name, refinemap, varT, dict_training, X_PAD_TEMP, XObserved);
    
    cnsrall= csnr(double(uint8(X_PAD_TEMP(1:height-1, 1:width-1))), X_PAD(1:height-1, 1:width-1), pad+5, pad+5)
    ssimall= ssim_index(double(uint8(X_PAD_TEMP(1+pad+5:height-pad-5-1, 1+pad+5:width-pad-5-1))) , X_PAD(1+pad+5:height-pad-5-1, 1+pad+5:width-pad-5-1) )
    
    disp('Refinement step....');    
    refinemap=zeros(height, width); LRHR=1; varT=100;
    [X_PAD_TEMP,~]=RkNNAR(the, the2, the3, LRHR,dict_name, refinemap, varT, dict_training, X_PAD_TEMP, XObserved);
    
    cnsrall= [cnsrall csnr(double(uint8(X_PAD_TEMP(1:height-1, 1:width-1))), X_PAD(1:height-1, 1:width-1), pad+5, pad+5)]
    ssimall= [ssimall ssim_index(double(uint8(X_PAD_TEMP(1+pad+5:height-pad-5-1, 1+pad+5:width-pad-5-1))) , X_PAD(1+pad+5:height-pad-5-1, 1+pad+5:width-pad-5-1) )]

if ch==3
    X_Final=zeros(height-2*pad, width-2*pad);
    X_PAD_BIC(:,:,1)=X_PAD_TEMP;
    for k=1:3
        X_Final(:,:,k)= X_PAD_BIC(1+pad:height-pad, 1+pad:width-pad,k);
    end
    imwrite((ycbcr2rgb(uint8(X_Final))), [Output '_RkNNAR.bmp']);
else
    X_PAD_TEMP= X_PAD_TEMP(1+pad:height-pad, 1+pad:width-pad);
    imwrite(uint8(X_PAD_TEMP), [Output '_RkNNAR.bmp']);
end


csvwrite([Output '_csnr_' int2str(the) '_' int2str(the2) '_' int2str(the3*100) '.txt'],cnsrall);
csvwrite([Output  '_ssim_' int2str(the) '_' int2str(the2) '_' int2str(the3*100) '.txt'],ssimall);


