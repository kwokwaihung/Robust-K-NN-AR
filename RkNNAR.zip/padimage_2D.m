function output=padimage_2_detail(f,pd1, pd2, pd3, pd4)

% This function 2D pads 1 channel or 3 channel images.

% f is input image to be padded
% pd1,pd2,pd3,pd4 is number of pixels to be padded

[y,x,ch]= size(f);

% x is width of image
% y is height of image

if ch==1
    output= [ rot90(f,2)  flipud(f)  rot90(f,2)
              fliplr(f)   f          fliplr(f)
              rot90(f,2)  flipud(f)  rot90(f,2)];

    output= output(y+1-pd1:y+y+pd2, x+1-pd3:x+x+pd4);
    
else
    
    output_RGB= zeros(y+pd1+pd2, x+pd3+pd4, 3);
    
    f1= f(:,:,1);
    output= [ rot90(f1,2)  flipud(f1)  rot90(f1,2)
              fliplr(f1)   f1          fliplr(f1)
              rot90(f1,2)  flipud(f1)  rot90(f1,2)];
    
    output= output(y+1-pd1:y+y+pd2, x+1-pd3:x+x+pd4);
    output_RGB(:,:,1)= output;
    
    
    f1= f(:,:,2);
    output= [ rot90(f1,2)  flipud(f1)  rot90(f1,2)
              fliplr(f1)   f1          fliplr(f1)
              rot90(f1,2)  flipud(f1)  rot90(f1,2)];
    
    output= output(y+1-pd1:y+y+pd2, x+1-pd3:x+x+pd4);
    output_RGB(:,:,2)= output;
        
    
    f1= f(:,:,3);
    output= [ rot90(f1,2)  flipud(f1)  rot90(f1,2)
              fliplr(f1)   f1          fliplr(f1)
              rot90(f1,2)  flipud(f1)  rot90(f1,2)];
    
    output= output(y+1-pd1:y+y+pd2, x+1-pd3:x+x+pd4);
    output_RGB(:,:,3)= output;
    
    output=output_RGB;
       
end


return;
