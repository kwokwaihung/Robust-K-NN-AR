function XBic=Refine_2(XBic,XObserved,height, width, th)

for i=2:height/2-2
    for j=2:width/2-2
        
        Xn=XObserved(i:i+1,j:j+1);
        XnMax= max(max(Xn)); XnMin= min(min(Xn));
        
        if XBic(i*2-1 +1, j*2-1+1)>XnMax+th
            XBic(i*2-1 +1, j*2-1+1)=XnMax+th;
        elseif XBic(i*2-1 +1, j*2-1+1)<XnMin-th
            XBic(i*2-1 +1, j*2-1+1)=XnMin-th;
        end
        
        if XBic(i*2-1 +1, j*2-1+1)>255
            XBic(i*2-1 +1, j*2-1+1)=255;
        elseif XBic(i*2-1 +1, j*2-1+1)<0
            XBic(i*2-1 +1, j*2-1+1)=0;
        end
        
        Xn=[XObserved(i,j) XObserved(i,j+1) XBic(i*2-1 +1, j*2-1+1) XBic(i*2-1 -1, j*2-1+1)];
        XnMax= max(max(Xn)); XnMin= min(min(Xn));
        
        if  XBic(i*2-1 , j*2-1+1)>XnMax+th
            XBic(i*2-1 , j*2-1+1)=XnMax+th;
        elseif  XBic(i*2-1 , j*2-1+1)<XnMin-th
            XBic(i*2-1 , j*2-1+1)=XnMin-th;
        end
        
        if  XBic(i*2-1 , j*2-1+1)>255
            XBic(i*2-1 , j*2-1+1)=255;
        elseif  XBic(i*2-1 , j*2-1+1)<0
            XBic(i*2-1 , j*2-1+1)=0;
        end
        
        Xn=[XObserved(i,j) XObserved(i+1,j) XBic(i*2-1 +1, j*2-1+1) XBic(i*2-1 +1, j*2-1-1)];
        XnMax= max(max(Xn)); XnMin= min(min(Xn));
        
        if XBic(i*2-1 +1, j*2-1)>XnMax+th
            XBic(i*2-1 +1, j*2-1)=XnMax+th;
        elseif XBic(i*2-1 +1, j*2-1)<XnMin-th
            XBic(i*2-1 +1, j*2-1)=XnMin-th;
        end
        
        if XBic(i*2-1 +1, j*2-1)>255
            XBic(i*2-1 +1, j*2-1)=255;
        elseif XBic(i*2-1 +1, j*2-1)<0
            XBic(i*2-1 +1, j*2-1)=0;
        end
        
    end
end

return ;

